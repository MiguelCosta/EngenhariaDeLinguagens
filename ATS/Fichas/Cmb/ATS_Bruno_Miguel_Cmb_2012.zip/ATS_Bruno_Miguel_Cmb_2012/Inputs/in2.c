void imprime(string nome)
{
	string msg;
	string msg2;
	int a;
	string b;

	msg = "blabla";
	msg2 = "bilu blilu";
	scan(a);
	print("ola");
	if (a == 1) { 
		print("THEN 1");
		if (b) {
			max(1,5);
		}
		print("THEN 2");
	}
	else {
		print("ELSE 1");
		print("ELSE 2");
	}
	print(b);
	while ( msg != b) {
		print("Dentro do WHILE");
		if (a) {
			msg = "e é isto";
		}
		else {
			msg = "e é aquilo";
		}
	}
	print("pois");
	min(a,55);
	return 1+2;
}
