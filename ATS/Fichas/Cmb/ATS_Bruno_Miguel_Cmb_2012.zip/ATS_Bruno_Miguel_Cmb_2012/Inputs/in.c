void imprime(string nome)
{
	string msg;
	msg = "blabla";
	print (nome);
	print (msg);
}

int main(int x, int y)
{
	int a;
	int b;
	
	a=2+1;
	
	if(a==2) {
		a = a + 1;
		b = 3;
	}
	else
		b = 5;
	
	while (a<5)
	{
		a = a+5 * 3;
	}
	
	b = xtop(a+2*3,a);
	
	print (a);
	
	scan (a);
}

bool xtop (bool t, int i)
{
	string s;
	
	s = "luis";
	
	imprime (s);
	
	return s;
}
